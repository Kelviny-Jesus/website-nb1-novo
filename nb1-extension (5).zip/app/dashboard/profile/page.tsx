import ProfileTab from "@/components/dashboard/ProfileTab"

export default function ProfilePage() {
  return (
    <div className="min-h-full p-6">
      <ProfileTab />
    </div>
  )
}

