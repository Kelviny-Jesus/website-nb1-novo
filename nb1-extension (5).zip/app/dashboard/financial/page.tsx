import FinancialTab from "@/components/dashboard/FinancialTab"

export default function FinancialPage() {
  return (
    <div className="min-h-full p-6">
      <FinancialTab />
    </div>
  )
}

