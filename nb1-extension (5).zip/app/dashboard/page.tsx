"use client"

import { Button } from "@/components/ui/button"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { UserCircle, MapPin, Film, Phone, Calendar, Home, Heart } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import ProfilePicture from "@/components/ProfilePicture"
import { useToast } from "@/components/ui/use-toast"
import Image from "next/image"

interface UserData {
  full_name: string
  email: string
  phone?: string
  birth_date?: string
  street_address?: string
  address_number?: string
  city?: string
  state?: string
  hobbies?: string[]
  favorite_movie_styles?: string[]
  favorite_series_styles?: string[]
  profile_picture?: string
}

export default function Dashboard() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const { toast } = useToast()

  const handleProfilePictureUpdate = async (imageUrl: string) => {
    try {
      const token = localStorage.getItem("session_token")
      if (!token) throw new Error("No session token found")

      const response = await fetch("https://n8n-webhooks.bluenacional.com/webhook/nb1/api/user/profile", {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ profile_picture: imageUrl }),
      })

      if (!response.ok) throw new Error("Failed to update profile")

      setUserData((prev) => (prev ? { ...prev, profile_picture: imageUrl } : null))

      toast({
        title: "Success",
        description: "Profile picture updated successfully",
      })
    } catch (error) {
      console.error("Failed to update profile picture:", error)
      toast({
        title: "Error",
        description: "Failed to update profile picture",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const storedUserData = localStorage.getItem("userData")
        if (storedUserData) {
          setUserData(JSON.parse(storedUserData))
          setIsLoading(false)
          return
        }

        const token = localStorage.getItem("session_token")
        if (!token) {
          console.error("No session token found")
          router.push("/")
          return
        }

        const response = await fetch("https://n8n-webhooks.bluenacional.com/webhook/nb1/api/user/profile", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        })

        if (!response.ok) {
          if (response.status === 401) {
            localStorage.removeItem("session_token")
            router.push("/")
            throw new Error("Session expired. Please log in again.")
          }
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const data = await response.json()
        setUserData(data)
        localStorage.setItem("userData", JSON.stringify(data))
      } catch (error) {
        console.error("Failed to fetch user data:", error)
        setUserData(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchUserData()
  }, [router])

  return (
    <div className="min-h-screen bg-[#0A0B14] p-6">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Welcome Section with Profile Picture */}
        <div className="text-center space-y-6 py-12">
          <div className="relative mx-auto w-fit">
            <ProfilePicture
              currentImageUrl={userData?.profile_picture}
              onImageUpdate={handleProfilePictureUpdate}
              size="lg"
            />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-white">
              {isLoading ? (
                <span className="inline-block w-48 h-8 bg-gray-700 animate-pulse rounded"></span>
              ) : (
                `Welcome, ${userData?.full_name || "User"}!`
              )}
            </h1>
            <p className="text-gray-400 text-lg">Here's your profile overview</p>
          </div>
        </div>

        {/* Profile Summary Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {/* Basic Information Card */}
          <Link href="/dashboard/profile">
            <Card className="bg-gradient-to-b from-[#1A1D2E] to-[#131629] border-gray-800 hover:border-gray-700 transition-all cursor-pointer">
              <CardHeader className="flex flex-row items-center space-x-4 pb-4">
                <UserCircle className="w-8 h-8 text-blue-500" />
                <CardTitle className="text-xl text-white">Basic Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-gray-400">
                  <div className="flex items-center space-x-2">
                    <Phone className="w-4 h-4" />
                    <span>{userData?.phone || "Not set"}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4" />
                    <span>{userData?.birth_date || "Not set"}</span>
                  </div>
                  <Button variant="ghost" className="mt-4 w-full justify-start text-blue-400 hover:text-blue-300">
                    View Details →
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Address Card */}
          <Link href="/dashboard/profile">
            <Card className="bg-gradient-to-b from-[#1A1D2E] to-[#131629] border-gray-800 hover:border-gray-700 transition-all cursor-pointer">
              <CardHeader className="flex flex-row items-center space-x-4 pb-4">
                <MapPin className="w-8 h-8 text-green-500" />
                <CardTitle className="text-xl text-white">Address</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-gray-400">
                  <div className="flex items-center space-x-2">
                    <Home className="w-4 h-4" />
                    <span>
                      {userData?.street_address
                        ? `${userData.street_address}, ${userData.address_number}`
                        : "Address not set"}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4" />
                    <span>{userData?.city ? `${userData.city}, ${userData.state}` : "Location not set"}</span>
                  </div>
                  <Button variant="ghost" className="mt-4 w-full justify-start text-green-400 hover:text-green-300">
                    View Details →
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Cultural Preferences Card */}
          <Link href="/dashboard/profile">
            <Card className="bg-gradient-to-b from-[#1A1D2E] to-[#131629] border-gray-800 hover:border-gray-700 transition-all cursor-pointer">
              <CardHeader className="flex flex-row items-center space-x-4 pb-4">
                <Heart className="w-8 h-8 text-purple-500" />
                <CardTitle className="text-xl text-white">Cultural Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Hobbies</label>
                    <div className="flex flex-wrap gap-1">
                      {userData?.hobbies?.slice(0, 3).map((hobby) => (
                        <Badge key={hobby} variant="secondary" className="bg-[#21262D] text-white">
                          {hobby}
                        </Badge>
                      ))}
                      {(userData?.hobbies?.length || 0) > 3 && (
                        <Badge variant="secondary" className="bg-[#21262D] text-white">
                          +{(userData?.hobbies?.length || 0) - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400">Entertainment</label>
                    <div className="flex items-center space-x-2">
                      <Film className="w-4 h-4 text-gray-400" />
                      <span className="text-gray-400">
                        {userData?.favorite_movie_styles?.length || 0} movie genres,{" "}
                        {userData?.favorite_series_styles?.length || 0} series genres
                      </span>
                    </div>
                  </div>
                  <Button variant="ghost" className="mt-4 w-full justify-start text-purple-400 hover:text-purple-300">
                    View Details →
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Floating NB1 Logo */}
        <div className="relative w-full h-48 mt-12">
          <div className="absolute left-1/2 transform -translate-x-1/2 animate-float">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ICON-NUMBERONE-OFC-unscreen-2rlFGjCNaLYTMxnF8huXplEwcv1KGy.gif"
              alt="NB1 Logo"
              width={128}
              height={128}
              className="h-32 w-32"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

