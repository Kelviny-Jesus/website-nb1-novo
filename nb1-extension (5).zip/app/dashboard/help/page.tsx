import HelpTab from "@/components/dashboard/HelpTab"

export default function HelpPage() {
  return (
    <div className="min-h-screen bg-[#0D1117] text-white">
      <HelpTab />
    </div>
  )
}

