import "./globals.css"
import { Inter } from "next/font/google"
import { IntlProvider } from "react-intl"
import en from "@/locales/en.json"
import es from "@/locales/es.json"
import pt from "@/locales/pt.json"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

const messages = {
  en,
  es,
  pt,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const locale = "en" // You can make this dynamic based on user preference

  return (
    <html lang={locale}>
      <IntlProvider messages={messages[locale]} locale={locale} defaultLocale="en">
        <body className={inter.className}>{children}</body>
      </IntlProvider>
    </html>
  )
}



import './globals.css'

export const metadata = {
      generator: 'v0.dev'
    };
