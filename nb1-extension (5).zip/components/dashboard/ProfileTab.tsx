"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Check, ChevronsUpDown } from "lucide-react"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useIntl } from "react-intl"
import axios from "axios"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import AuthenticationModal from "@/components/modals/AuthenticationModal"
import EditBasicInfoModal from "@/components/modals/EditBasicInfoModal"
import EditAddressModal from "@/components/modals/EditAddressModal"
import EditCulturalModal from "@/components/modals/EditCulturalModal"

interface UserData {
  id: string
  full_name: string
  phone: string
  gender: string
  preferred_currency: string
  preferred_language: string
  postal_code: string
  country: string
  state: string
  city: string
  street_address: string
  address_number: string
  address_complement: string
  hobbies: string[]
  favorite_movie_styles: string[]
  favorite_series_styles: string[]
  birth_date: string
  email: string
  plan_status: string
  user_status: string
}

interface MultiSelectProps {
  options: string[]
  value: string[]
  onChange: (value: string[]) => void
  placeholder: string
  emptyMessage: string
  label: string
}

function MultiSelect({ options, value, onChange, placeholder, emptyMessage, label }: MultiSelectProps) {
  const [open, setOpen] = useState(false)
  const { formatMessage } = useIntl()

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full h-[60px] justify-between bg-[#161B22] border-gray-800 text-white hover:bg-[#21262D] relative"
        >
          <ScrollArea className="w-[calc(100%-2rem)] h-[48px] py-1">
            <div className="flex flex-wrap gap-1">
              {value.length === 0 ? (
                <span className="text-gray-500">{placeholder}</span>
              ) : (
                value.map((item) => (
                  <Badge key={item} variant="secondary" className="bg-[#21262D] text-white whitespace-nowrap">
                    {formatMessage({ id: item })}
                  </Badge>
                ))
              )}
            </div>
          </ScrollArea>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50 absolute right-3" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0 bg-[#0D1117] border-gray-800">
        <Command className="bg-transparent">
          <CommandInput placeholder={placeholder} className="text-white" />
          <CommandList>
            <CommandEmpty>{emptyMessage}</CommandEmpty>
            <CommandGroup>
              <ScrollArea className="h-[300px]">
                {options.map((option) => (
                  <CommandItem
                    key={option}
                    onSelect={() => {
                      onChange(value.includes(option) ? value.filter((item) => item !== option) : [...value, option])
                    }}
                    className="text-white hover:bg-[#21262D]"
                  >
                    <Check className={cn("mr-2 h-4 w-4", value.includes(option) ? "opacity-100" : "opacity-0")} />
                    {formatMessage({ id: option })}
                  </CommandItem>
                ))}
              </ScrollArea>
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}

const MAX_RETRIES = 3
const RETRY_DELAY = 1000 // 1 second
const REQUEST_TIMEOUT = 10000 // 10 seconds

type EditMode = "basic" | "address" | "cultural" | null

export default function ProfileTab() {
  const [editMode, setEditMode] = useState<EditMode>(null)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()
  const router = useRouter()
  const { formatMessage } = useIntl()
  const [userData, setUserData] = useState<UserData | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [showAuthDialog, setShowAuthDialog] = useState(false)
  const [showCulturalDialog, setShowCulturalDialog] = useState(false)
  const [authData, setAuthData] = useState({ email: "", password: "" })
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const [culturalData, setCulturalData] = useState({
    hobbies: [] as string[],
    favorite_movie_styles: [] as string[],
    favorite_series_styles: [] as string[],
  })

  useEffect(() => {
    if (userData) {
      setCulturalData({
        hobbies: Array.isArray(userData.hobbies) ? userData.hobbies : [],
        favorite_movie_styles: Array.isArray(userData.favorite_movie_styles) ? userData.favorite_movie_styles : [],
        favorite_series_styles: Array.isArray(userData.favorite_series_styles) ? userData.favorite_series_styles : [],
      })
    }
  }, [userData])

  const handleEdit = async (mode: EditMode) => {
    try {
      setIsLoading(true)
      setError(null)

      const userData = localStorage.getItem("userData")
      if (!userData) {
        throw new Error("User data not found")
      }

      const { email } = JSON.parse(userData)

      const response = await fetch("https://n8n-blue.up.railway.app/webhook/nb1/api/user/check", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      })

      if (!response.ok) {
        throw new Error("Failed to verify user")
      }

      setEditMode(mode)
      setShowAuthModal(true)
    } catch (err) {
      console.error("Error:", err)
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleAuthenticate = async (email: string, password: string) => {
    try {
      const response = await fetch("https://n8n-blue.up.railway.app/webhook/nb1/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      if (!response.ok) {
        throw new Error("Invalid credentials")
      }

      const data = await response.json()

      // Store the new session token
      if (data.session_token) {
        localStorage.setItem("session_token", data.session_token)
      }

      setShowAuthModal(false)
      // The edit modal will be shown automatically since editMode is set
    } catch (err) {
      throw new Error("Authentication failed")
    }
  }

  const handleCloseAuth = () => {
    setShowAuthModal(false)
    setEditMode(null)
  }

  const handleCloseEdit = () => {
    setEditMode(null)
  }

  // Get user email for auth modal
  const userDataLocal = localStorage.getItem("userData")
  const userEmail = userDataLocal ? JSON.parse(userDataLocal).email : ""

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsAuthenticating(true)
    setError(null)

    try {
      const response = await fetch("https://n8n-blue.up.railway.app/webhook/nb1/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(authData),
      })

      if (!response.ok) {
        throw new Error("Invalid credentials")
      }

      const data = await response.json()
      if (data.token) {
        localStorage.setItem("authToken", data.token)
        setShowAuthDialog(false)
        setShowCulturalDialog(true)
      } else {
        throw new Error("No token received")
      }
    } catch (err) {
      console.error("Authentication error:", err)
      setError(err instanceof Error ? err.message : "Authentication failed")
    } finally {
      setIsAuthenticating(false)
      setAuthData({ email: "", password: "" })
    }
  }

  const handleEditCultural = () => {
    setShowAuthDialog(true)
  }

  const handleCulturalSubmit = async () => {
    if (userData) {
      try {
        const token = localStorage.getItem("authToken")
        if (!token) throw new Error("No auth token found")

        const response = await fetch("https://n8n-webhooks.bluenacional.com/webhook/nb1/api/user/profile", {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            ...userData,
            hobbies: culturalData.hobbies,
            favorite_movie_styles: culturalData.favorite_movie_styles,
            favorite_series_styles: culturalData.favorite_series_styles,
          }),
        })

        if (!response.ok) {
          const errorText = await response.text()
          throw new Error(`Failed to update preferences: ${errorText}`)
        }

        setUserData({
          ...userData,
          hobbies: culturalData.hobbies,
          favorite_movie_styles: culturalData.favorite_movie_styles,
          favorite_series_styles: culturalData.favorite_series_styles,
        })

        toast({
          title: "Success",
          description: "Cultural preferences have been updated.",
        })
      } catch (error) {
        console.error("Failed to update preferences:", error)
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to update preferences. Please try again.",
          variant: "destructive",
        })
      }
    }
    setShowCulturalDialog(false)
  }

  const handlePostalCodeChange = async (postalCode: string) => {
    if (postalCode.length !== 8) return

    try {
      const response = await axios.get(`https://viacep.com.br/ws/${postalCode}/json/`)
      if (response.data.erro) {
        setError("Invalid postal code")
      } else {
        if (userData) {
          setUserData({
            ...userData,
            country: "Brazil",
            state: response.data.uf,
            city: response.data.localidade,
            street_address: response.data.logradouro,
          })
        }
        setError(null)
      }
    } catch (error) {
      console.error("Failed to fetch address:", error)
      setError("Failed to fetch address information")
    }
  }

  const fetchUserData = useCallback(
    async (retryCount = 0) => {
      try {
        setIsLoading(true)
        setError(null)

        const storedUserData = localStorage.getItem("userData")
        if (storedUserData) {
          setUserData(JSON.parse(storedUserData))
          setIsLoading(false)
          return
        }

        const token = localStorage.getItem("session_token")
        if (!token) {
          console.error("No session token found")
          router.push("/")
          throw new Error("Authentication required. Please log in.")
        }

        console.log("Fetching user data with token:", token)

        const response = await fetch("https://n8n-webhooks.bluenacional.com/webhook/nb1/api/user/profile", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        })

        console.log("Profile response status:", response.status)

        if (!response.ok) {
          if (response.status === 401) {
            localStorage.removeItem("session_token")
            router.push("/")
            throw new Error("Session expired. Please log in again.")
          }
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const responseText = await response.text()
        console.log("Raw API Response:", responseText)

        let data
        try {
          data = JSON.parse(responseText)
        } catch (e) {
          console.error("JSON Parse Error:", e)
          throw new Error(`Invalid JSON response: ${responseText.substring(0, 100)}...`)
        }

        console.log("Parsed user data:", data)

        if (!data || typeof data !== "object" || !data.id) {
          throw new Error("Invalid data format received from server")
        }

        setUserData(data)
        localStorage.setItem("userData", JSON.stringify(data))
      } catch (error) {
        console.error("Failed to fetch user data:", error)
        setError(error instanceof Error ? error.message : String(error))

        if (error instanceof Error && error.message.includes("Authentication required")) {
          router.push("/")
        } else if (retryCount < MAX_RETRIES) {
          console.log(`Retrying... Attempt ${retryCount + 1} of ${MAX_RETRIES}`)
          setTimeout(() => fetchUserData(retryCount + 1), RETRY_DELAY)
        }
      } finally {
        setIsLoading(false)
      }
    },
    [router],
  )

  useEffect(() => {
    fetchUserData()

    return () => {
      // Cleanup function
      setUserData(null)
      setError(null)
      setIsLoading(false)
    }
  }, [fetchUserData])

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      {isLoading ? (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center space-y-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto"></div>
            <p className="text-white">Loading your profile...</p>
          </div>
        </div>
      ) : error ? (
        <div className="p-6">
          <Alert variant="destructive">
            <AlertDescription className="flex flex-col gap-2">
              <p>{error}</p>
              <Button onClick={() => fetchUserData()} variant="outline" className="w-full mt-2">
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Basic Information */}
          <Card className="bg-[#1A1D2E] border-gray-800">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-xl text-white">Basic Information</CardTitle>
                <CardDescription>Your personal information</CardDescription>
              </div>
              <Button variant="outline" onClick={() => handleEdit("basic")} className="text-white" disabled={isLoading}>
                Edit Information
              </Button>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm text-gray-400">Phone</Label>
                  <Input value={userData?.phone || ""} className="bg-[#131629] border-gray-800 text-white" readOnly />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm text-gray-400">Birth Date</Label>
                  <Input
                    value={userData?.birth_date || ""}
                    className="bg-[#131629] border-gray-800 text-white"
                    readOnly
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Address Information */}
          <Card className="bg-[#1A1D2E] border-gray-800">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-xl text-white">Address</CardTitle>
                <CardDescription>Your address information</CardDescription>
              </div>
              <Button
                variant="outline"
                onClick={() => handleEdit("address")}
                className="text-white"
                disabled={isLoading}
              >
                Edit Address
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm text-gray-400">Address</Label>
                <Input
                  value={userData?.street_address || ""}
                  className="bg-[#131629] border-gray-800 text-white"
                  readOnly
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm text-gray-400">Number</Label>
                  <Input
                    value={userData?.address_number || ""}
                    className="bg-[#131629] border-gray-800 text-white"
                    readOnly
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm text-gray-400">Complement</Label>
                  <Input
                    value={userData?.address_complement || ""}
                    className="bg-[#131629] border-gray-800 text-white"
                    readOnly
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm text-gray-400">City</Label>
                  <Input value={userData?.city || ""} className="bg-[#131629] border-gray-800 text-white" readOnly />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm text-gray-400">State</Label>
                  <Input value={userData?.state || ""} className="bg-[#131629] border-gray-800 text-white" readOnly />
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-gray-400">Postal Code</Label>
                <Input
                  value={userData?.postal_code || ""}
                  className="bg-[#131629] border-gray-800 text-white"
                  readOnly
                />
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-gray-400">Country</Label>
                <Input value={userData?.country || ""} className="bg-[#131629] border-gray-800 text-white" readOnly />
              </div>
            </CardContent>
          </Card>

          {/* Cultural Preferences */}
          <Card className="bg-[#1A1D2E] border-gray-800">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-xl text-white">Cultural Preferences</CardTitle>
                <CardDescription>Your interests and preferences</CardDescription>
              </div>
              <Button
                variant="outline"
                onClick={() => handleEdit("cultural")}
                className="text-white"
                disabled={isLoading}
              >
                Edit Preferences
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label className="text-sm text-gray-400">Hobbies</Label>
                <div className="flex flex-wrap gap-2">
                  {userData?.hobbies?.map((hobby) => (
                    <Badge key={hobby} className="bg-[#131629] text-white">
                      {hobby}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-gray-400">Favorite Movie Styles</Label>
                <div className="flex flex-wrap gap-2">
                  {userData?.favorite_movie_styles?.map((style) => (
                    <Badge key={style} className="bg-[#131629] text-white">
                      {style}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <Label className="text-sm text-gray-400">Favorite Series Styles</Label>
                <div className="flex flex-wrap gap-2">
                  {userData?.favorite_series_styles?.map((style) => (
                    <Badge key={style} className="bg-[#131629] text-white">
                      {style}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Authentication Modal */}
      <AuthenticationModal
        isOpen={showAuthModal}
        onClose={handleCloseAuth}
        onAuthenticate={handleAuthenticate}
        email={userEmail}
      />

      {/* Edit Modals */}
      {editMode === "basic" && !showAuthModal && <EditBasicInfoModal isOpen={true} onClose={handleCloseEdit} />}
      {editMode === "address" && !showAuthModal && <EditAddressModal isOpen={true} onClose={handleCloseEdit} />}
      {editMode === "cultural" && !showAuthModal && <EditCulturalModal isOpen={true} onClose={handleCloseEdit} />}
    </div>
  )
}

