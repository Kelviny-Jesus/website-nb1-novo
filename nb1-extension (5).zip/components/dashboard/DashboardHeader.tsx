"use client"

export default function DashboardHeader() {
  return null // Remove the header component entirely
}

